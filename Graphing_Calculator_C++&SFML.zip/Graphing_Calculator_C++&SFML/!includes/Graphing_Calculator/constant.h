#ifndef CONSTANT_H
#define CONSTANT_H

//const int DISTANCE = 40;
const int SCREEN_WIDTH = 600;
const int SCREEN_HEIGHT = 400;

#endif // CONSTANT_H
