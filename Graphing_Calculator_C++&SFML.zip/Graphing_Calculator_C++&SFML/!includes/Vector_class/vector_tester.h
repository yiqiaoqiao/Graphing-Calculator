#ifndef VECTOR_TESTER_H
#define VECTOR_TESTER_H
#include <iostream>
#include"../../!includes/Vector_class/vector.h"
using namespace std;

void big_three_tester();
void member_access_tester();
void push_pop_tester();
void insert_erase_tester();
void size_capacity_tester();


#endif // VECTOR_TESTER_H
