#ifndef QUEUE_WORKREPORT_H
#define QUEUE_WORKREPORT_H
/*
 * Features:
        -Not Implemented:
              everything implemented
        -Implemented:
              everything implemented
        -Partly implemented:
              everything implemented

    Bugs     : No bugs

    Reflections:
        Queue class is harder to write compare to stack class, but still not that hard to do.
 */
#endif // QUEUE_WORKREPORT_H
