#ifndef STACK_TEST_H
#define STACK_TEST_H

#include "../../!includes/List_Functions/stack.h"
Stack<int> _stack_one();
Stack<char> _stack_two();
Stack<string> _stack_three();

void _stack_test_push();
void _stack_test_pop();
void _stack_test_top();
void test_stack_big_three();
void _test_stack();
#endif // STACK_TEST_H
