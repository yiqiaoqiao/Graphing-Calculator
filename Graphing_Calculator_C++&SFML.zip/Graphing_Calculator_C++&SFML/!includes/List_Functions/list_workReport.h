#ifndef LIST_WORKREPORT_H
#define LIST_WORKREPORT_H
/*
 * Features:
        -Not Implemented:
              everything implemented
        -Implemented:
              everything implemented
        -Partly implemented:
              everything implemented

    Bugs     : No bugs

    Reflections:
        This is simpler because I already finish all the functions in the node.h file.
 */
#endif // LIST_WORKREPORT_H
