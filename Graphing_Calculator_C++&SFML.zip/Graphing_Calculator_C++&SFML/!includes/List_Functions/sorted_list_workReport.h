#ifndef SORTED_LIST_WORKREPORT_H
#define SORTED_LIST_WORKREPORT_H
/*
 * Features:
        -Not Implemented:
              everything implemented
        -Implemented:
              everything implemented
        -Partly implemented:
              everything implemented

    Bugs     : No bugs

    Reflections:
        This is easier comparing to Stack and Queue. Everything is already written before in the last project.
 */
#endif // SORTED_LIST_WORKREPORT_H
