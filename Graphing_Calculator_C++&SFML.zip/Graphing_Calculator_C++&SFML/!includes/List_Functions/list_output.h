#ifndef LIST_OUTPUT_H
#define LIST_OUTPUT_H
/*
=======================================
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->{54}->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->{6}->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->{35}->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
?

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->{35}->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->{6}->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->{54}->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
p

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->{91}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[91]->{94}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[91]->[94]->{97}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
a

?: 77
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[91]->[94]->[97]->{77}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
n

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[91]->[94]->[97]->[77]->{54}->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
b

?: 55
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[91]->[94]->[97]->[77]->{55}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[91]->[94]->[97]->[77]->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{91}->[94]->[97]->[77]->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{94}->[97]->[77]->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{97}->[77]->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{77}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{54}->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{35}->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{51}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
a

?: 44
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{44}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
d

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
b

?: 33
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{33}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[33]->{43}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[33]->[43]->{43}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[33]->[43]->[43]->{43}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
r

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[33]->[43]->[43]->[43]->{46}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
h

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{33}->[43]->[43]->[43]->[46]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
e

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[33]->[43]->[43]->[43]->{46}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
x

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
---------- END ----------------
Press <RETURN> to close this window...

 */




/*
//=================================== Test Search =========================================
=======================================
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
s

?: 54
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->{54}->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
s

?: 35
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->{35}->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
s

?: 17
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
[6]->[54]->[6]->[35]->{17}->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
s

?: 6
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
s

?: -22
..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
{6}->[54]->[6]->[35]->[17]->|||
[R]andom [A]fter  [B]efore [D]elete [S]earch [P]revious [N]ext  [H]ome  [E]nd
x

..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..   ..
---------- END ----------------
Press <RETURN> to close this window...
 */




/*
========================= Test Rest Functions =========================
List: H->[6]->[54]->[6]->[35]->[17]->|||
------------- Copy CTOR -----------
List 2: H->[6]->[54]->[6]->[35]->[17]->|||
------------- Assignment Operator -----------
List 3: H->[6]->[54]->[6]->[35]->[17]->|||
------------- [] Function -----------
Element at position 3: 35

========================== END ===========================
Press <RETURN> to close this window...
 */
#endif // LIST_OUTPUT_H
