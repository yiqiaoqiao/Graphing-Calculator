#ifndef WORKREPORT_H
#define WORKREPORT_H
/*
 * Features:
        -Not Implemented:
              everything implemented
        -Implemented:
              everything implemented
        -Partly implemented:
              everything implemented

    Bugs     : No bugs

    Reflections:
        This is easier than the polynomial project.
 */
#endif // WORKREPORT_H
