#ifndef STACK_WORKREPORT_H
#define STACK_WORKREPORT_H
/*
 * Features:
        -Not Implemented:
              everything implemented
        -Implemented:
              everything implemented
        -Partly implemented:
              everything implemented

    Bugs     : No bugs

    Reflections:
        This project is not as hard as I think. Stack class is easy to write because it is base on the node class
        we wrote last week.
 */
#endif // STACK_WORKREPORT_H
