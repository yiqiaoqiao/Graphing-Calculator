#ifndef WORKREPORT_H
#define WORKREPORT_H
/*
 * Features:
        -Not Implemented:
              everything implemented
        -Implemented:
              everything implemented
        -Partly implemented:
              everything implemented

    Bugs     : No bugs

    Reflections:
        I am very happy that I finish this project. Although it takes me a long time, I am very satisfied with the outcome.
        I really like the feeling that I am putting everything together, not much to debug, I focused more on the designing
        of the calculator, how to make it look nicer, and try to make buttons for the user to click on, and trying to find
        more bugs to fix, and making the whole thing look beautiful.
 */
#endif // WORKREPORT_H
